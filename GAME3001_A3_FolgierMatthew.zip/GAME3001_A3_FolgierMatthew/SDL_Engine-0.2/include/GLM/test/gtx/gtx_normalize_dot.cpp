#include <glm/gtx/normalize_dot.hpp>

int main()
{
	int Error(0);

	return Error;
}
