#include <glm/gtx/extended_min_max.hpp>

int main()
{
	int Error(0);

	return Error;
}
